var g_planet_url = g_game_url+'ajax/ajaxPlanet.php';//direccion de accion [TODO]Hacer un json precharge de esto
var g_region_url = g_game_url+'region.php';
var g_image_url = g_game_url+'img/';

var g_region_action_class= 'region_action';//Clase de boton de accion
var g_region_action_wrapper_class= 'region_action_wrapper';//Clase de boton de accion

var iGlobalTime = 0;
var old_xeno;
  
  
$(document).ready(function(){
    if(validateInitialPlanetXeno()){
        
        renderPlanetMap();
        
        addTime = function(){iGlobalTime++};
        setInterval(function() {addTime();}, 1000);
        xeno['time'] = iGlobalTime; //tiemplo de jclock se calcula
        //Inicializar jugador seleccionado
        //Inicializa Behaviors
        $('td').live('click',function(){actionEngine(this)});
        //$('input.visitregion').live('click',function(){actionEngine(this)});
        $('li.ability').live('click',function(){activeAbility(this)});
        //Acciones de la Region
        $('.'+g_region_action_class).live('click',function(){attackRegionAction(this);return false});
        //$('li.resource').live('click',function(){activeAbility(this)});
        $("#InnerBattleReport").accordion({autoHeight: false});
        //Imprime los datos basicos en pantalla
        //processAjaxSuccess(xeno);
        callStatus();
    }
});

/***********************************************************
 * PRINCIPAL
 **********************************************************/
function validateInitialPlanetXeno(){
    if(validateInitialXeno())
    {
         return true;
    }
    else{
        return false;
    }
}

function processAjaxError(XMLHttpRequest, textStatus, errorThrown){
    errorMsg('Error de Coneccion[1]. Si manda detalles de este error en el foro podra ganar algunos bonuses');
    continueMsg();
 }
 
 function processAjaxSuccess(data,force){
    
    if(data == 1){
        errorMsg('Error de Coneccion[2]. Si manda detalles de este error en el foro podra ganar algunos bonuses');
        continueMsg();
     }
     else{
        //$('#Clockout').countdown('destroy');//por si las webs
        
        if(typeof(data) == 'string'){
            var data = $.parseJSON(data);
        }
        last_xeno = xeno;
        xeno = data;
        
        xeno['time'] = iGlobalTime;
        //phaseManager(true,{hasWarning:true});
        var activeRegionId = getActiveRegionId();
        deactiveRegions();
        activeRegion(activeRegionId);
        msg(xeno['msg']);
        fillAbilitiesMenu();
        fillMapWithBattles();
        fillMapWithResources();
        fillMapWithColonies();
        fillMapWithPlayers();
        fillReinforcements();
        fillResourcesMenu();
        fillTeamInfo(activeRegionId);
    }
 }


 function actionEngine(target_tile){

    // Obtener Accion
    var action_id = getActiveAbilityId();
    if((action_id))//Existe una accion [TODO] Pasar ese -1 desde la variable Xeno
    {
      deactiveAbilities();
    }
    else {
      var id = getRegionId(target_tile);
      //console.log(id,'actionEngine');
      if(id){
        fillMapWithBattles();
        fillRegionInfo(xeno['regions'][id]);
        fillArmiesInfo(xeno['regions'][id]);
        fillReinforcement(xeno['regions'][id],xeno['battles']['sended']);
        showRegionInfo();
        activeRegion(id);
        fillTeamInfo(id);
        //console.log(id,'actionEngine si tiene id');
      }
      else{
          //console.error(id,'actionEngine NO tiene id');
      }
    }
  
 }
 function fillReinforcements(){
      //Imprimir los jugadores que estan llegando
 var list_player = new Array();
 var reinforcements = xeno['battles']['sended'];
var players =  xeno['players'];
 if (isDefined(reinforcements) ){
      
  $.each(reinforcements,function(key,reinforcement){
        var player = players[reinforcement['player_id']];
        var type = playerType(player, xeno['player']);
       
       var region_id = reinforcement['to_region'];
       var playername = reinforcement['username'];
        //if(($.inArray(playername,list_player[region_id]))==-1){//No imprimir si ya lo imprimimos
          list_player[region_id] = new Array();
          list_player[region_id].push(playername);
          var reg = getRegion(region_id);
          $(reg).append('<span class="player arriving '+type+'">'+playername+'</span> ');
        //}
    })
  } 
  else{
         //console.log("No esta definido reinforcement?");
  }
 }
 
/***********************************************************
 * PLAYERS
 **********************************************************/
function fillMapWithPlayers(){
   $('.planet_map .player').remove();
   var regions = xeno['regions'];
   if(exist(regions)){
     for(key in regions){
         region = regions[key];
         var players = getPlayersByRegionId(region['id']);
         for(pKey in players){
             player = players[pKey];
             var regDom = getRegion(region['id']);
             $(regDom).append(renderPlayer(player,xeno['player']));
         }
         
     }

   }
   /*
   if(players!=null){
     $.each(players,function(key,player){
       var reg = getRegion(player['region_id']);
       var type ='enemy';
       if(player['username']==you['username']){
         type = 'myself';
       }
       if(player['type']=='A'){
         type = 'AI';
       }
       $(reg).append('<span class="player '+type+'">'+player['username']+'</span> ');
     });
   }*/

 }
/***********************************************************
 * ARMIES
 **********************************************************/ 
 function renderArmies(player_id,region_id){
   
   var armies = xeno['armies'][region_id];
   var DOM = '<ul class="inner-accord">';
   if(armies!=null){
     $.each(armies,function(key,army){
       if((army['player_id']==player_id)&&(army['region_id']==region_id)){
        var player = xeno['players'][army['player_id']];
        var myself = xeno['player'];

        DOM = DOM + '<li><span>'+army['size']+'</span> '+renderCreature(army,player,myself,false,'','',true)+' : '+renderArmyPosition(army['position'])+'</li>';
       }
       
     });
   }
   DOM = DOM + '</ul>';
    
   return DOM;
 }
 /***********************************************************
 * FUSIONAR ESTO ALGUNA VES
 **********************************************************/
 
  /*renderBattle: Imprimir html de batalla*/
  function renderBattleTag(region){
    //console.log(battle_id,'Id de la batalla');
    var DOM = '';
    var battle = getBattleByRegion(region['id']);
    var name ='<a href="region.php?region_id='+region['id']+'"> '+ region['name']+'</a>';
    if(battle){
        var phase = battle['phase'];
        DOM = DOM + '<div class="battle_tag phase'+phase+'" id="BattleTag'+region['id']+'_'+battle['id']+'">'+name+'</div>';
    }
    else{
        DOM = DOM + '<div class="region_tag ui-state-transparent" id="RegionTag'+region['id']+'">'+name+'</div>';
    }
    
    return DOM;
  } 
 function getBattleByRegion(region_id){
    battles = xeno['battles']['active'];
    //console.log(battles,'planet.js->getBattleByRegion');
    if(isDefined(battles)){
        //console.log('battles esta definido','planet.js->getBattleByRegion ');
        var battle_return = false;
        $.each(battles,function(key,battle){
            //console.log(battle['region_id']+'==?'+region_id,'planet.js->getBattleByRegion ->each battle[region_id]');
            if( parseInt(battle['region_id']) == parseInt(region_id ) ){
               // console.info('Esto esta funcionando');
                battle_return = battle;
                return false;
            }
        })
        //console.log('No hay ninguna bata単a en la region['+region_id+']','planet.js->getBattleByRegion ');
        return battle_return;
    }
    else{
        //console.log('battles no esta definido','planet.js->getBattleByRegion ');
        return false;
    }
 }
  
 /*renderArmyPosition: html de la posicion de la criatura*/
 function renderArmyPosition(army_position){
   return position[army_position]
 }
 
/***********************************************************
 * PLANETA
 **********************************************************/
 function fillMapWithResources(){
   var resources = xeno['planet']['resources'];
   if(resources != null){
    $.each(resources,function(key,resource){
     var reg = getRegion(resource['region_id']);
     var DOM = renderResource(resource);
     var val= $(reg).children('.resources').append(DOM);
     
   });  
   }
 }
 
  function fillMapWithColonies(){
   var regionWithColonies = xeno['colonies'];
   if(regionWithColonies != null){
    $.each(regionWithColonies,function(regionId,coloniesInRegion){
     var reg = getRegion(regionId);
     //console.log(coloniesInRegion,'fillMapWithcolonies');
     $(reg).children('.colonies').html("");
     $.each(coloniesInRegion,function(colonyId,colony){
         var DOM = renderColony(colony);
         var val= $(reg).children('.colonies').append(DOM);
     });

   });  
   }
 }
 
  /*function fillMapWithBattles(){
   var remove = $('.battle_tag').remove();
   var battles = xeno['battles']['active'];
   if(battles != null){
     $.each(battles,function(key,battle){
       region = getRegion(battle['region_id']);
       $(region).prepend(renderBattleTag(battle['id']));
       //console.log(region);
     });
   }
 }*/

 function fillMapWithBattles(){
   $('.battle_tag').remove();
   $('.region_tag').remove();
   var regions = xeno['regions'];
   if(regions != null){
     $.each(regions,function(key,region){
       region_dom = getRegion(key);
       $(region_dom).prepend(renderBattleTag(region));
       //console.log(region);
     });
   }
 }
 
/***********************************************************
 * PANEL DE BATALLA
 **********************************************************/ 
 function fillArmiesInfo(regionInfo){
   //Actualizar la lista de Jugadores
  //console.log(regionInfo,'fillBattleInfo');
  var region_id = regionInfo['id'];
  var myself = xeno['player'];
  var players = xeno['players'];
  var DOM = '';
  var count=0;
  var hasI = false; //variable que indica si tu army tiene unidades por ingresa
  var IDOM ='';
  $.each(players,function(key,player){
    var type ='enemy';
     if(player['username']==myself['username']){
       type = 'myself';
     }  
     if(player['type']=='A'){
       type = 'AI';
     }   
    if(regionInfo['id']==player['region_id']){
      if(type!='myself'){
          DOM = DOM + '<h3 class="'+type+'">'+player['username']+'</h3><div>'+renderArmies(player['player_id'],regionInfo['id']);
          count++;
      }  
      
      /*if(type=='myself'){
        if(armiesHasPosition('I',player['player_id'],region_id)){
          IDOM = IDOM + '<form id="ArmiesGetIntoRegion" name="ArmiesGetIntoRegio" action="'+g_region_url+'?region_id='+regionInfo['id']+'" method="get">';
          IDOM = IDOM + '<input id="GetIntoRegion'+regionInfo["id"]+'" class="visitregion" type="submit" value="Moverlos a '+regionInfo["name"]+'" />';
          IDOM = IDOM + '<input name="region_id" type="hidden" value="'+regionInfo['id']+'" />';
          IDOM = IDOM + '</form>';

        }
        DOM = DOM + IDOM;
      } */
      DOM = DOM +  '</div>';
      
    }
  })
  
  
  //$('#ArmyInfoInner').accordion("destroy");//jquery ui
  if(count==0){
      //DOM ='<img src="img/web/title-block2.jpg" class="img-block">';
      DOM ='<p class="inner">La region no tiene ninguna unidad</p>';
      $('#ArmyInfoInner').html(DOM);
  }
  else{
    $('#ArmyInfoInner').html(DOM);
    $('#ArmyInfoInner').accordion({autoHeight: false});
  }
     
 }
  
/***********************************************************
 * REGIONES
 **********************************************************/
function fillRegionInfo(regionInfo){
  if(typeof(regionInfo) == 'undefined'){
    $('#RegionInfo').html('Elija una region');
  }
  
  else{
  //Llenar la informacion de la region 
  var DOM = '<div class="inner-accord inner"><h4>'+regionInfo['name']+'</h4><p>'+regionInfo['desc']+'</p>';
  DOM = DOM + '<form id="VisitRegionForm" name="VisitRegionForm" action="'+g_region_url+'?region_id='+regionInfo['id']+'" method="get">';
  DOM = DOM + '<input id="VisitRegion'+regionInfo["id"]+'" class="visitregion" type="submit" value="Visitar Region" />';
  DOM = DOM + '<input name="region_id" type="hidden" value="'+regionInfo['id']+'" />';
  DOM = DOM + '</form></div>';
  $('#RegionInfo').html(DOM);
  
  //Crear los recursos por region
  var iDOM ='';
  var count =0;
  var resources = xeno['planet']['resources'];
  if(resources == null){
      iDOM = '<li><p>Esta Region no Tiene recursos</p></li>';
  }
  else{
    $.each(resources,function(key,resource){
        if(regionInfo['id'] == resource['region_id']){
         iDOM = iDOM +'<li>'+renderResource(resource)+'</li>';
         count++; 
    }
  });
  if(count==0){
      iDOM = '<li><p>Esta Region no Tiene recursos</p></li>';
   }    
  }
  
  $('#RegionInfo').append('<ul id = "RegionResources" class="inner inner-accord">'+iDOM+'<li class="clear"></li></ul>');
  }//else inicial si tiene datos
}

function getPlayerColonyByRegion(regionId){
   var regionColonies = xeno['colonies'][regionId];  
   var colony = false;
   for (colonyId in regionColonies){
       colony = regionColonies[colonyId];
       if(colony['allegiance'] == 'myself'){
           break;
       }
   }
   return colony;
}

function fillTeamInfo(region_id){

    var teams = xeno['teams'][region_id];
    var armies  = xeno['armies'][region_id];
    var region = xeno['regions'][region_id];
    
    var colony = getPlayerColonyByRegion(region_id);
    var unitRegionCounter=0;
   ////////////////////////////////////Rendering de las unidades regionales //////////////////////////////
   if(colony!= false){
       var regionColonies = xeno['colonies'][region_id];  

       
       var regionTeamInfo = $('#RegionTeamInfo'); 
       $(regionTeamInfo).html('');
       //console.log(isFromPlayer,'fillTeamInfo isFromPlayer');
           
       var teamWrapper = $('<div class="ui-state-transparent"></div>').appendTo(regionTeamInfo);
       $(teamWrapper).data('team_id',null);
       $(teamWrapper).append('<h4 class="ui-helper-clearfix ">Colonia '+colony['name']+'</h4>');
       var regionUl = $('<ul id="t0" class="team ui-helper-clearfix"></ul>').appendTo(teamWrapper);

       for(aKey in armies){
           var army = armies[aKey];
           if(army['team_id'] == null){
               if(army['allegiance'] =='myself'){
                   var dom = '<li id="a'+army['id']+'"  class="armyWrapper '+army['allegiance']+'"><div class="army"><img src="img/unit/'+army['creature_id']+'_small.png" id="a384" class="army_turn myself small"><p>'+army['size']+'</p></div></li>';
                   $(regionUl).append(dom);
                   unitRegionCounter++;
               }
           }
       }    

   }
   else{
       var regionTeamInfoDom = $('#RegionTeamInfo'); 
       $(regionTeamInfoDom).html('');
   }
   
   /*if(unitRegionCounter>0){
       $('#RegionTeamInfo').show();
   }
   else{
       $('#RegionTeamInfo').hide();
   }*/

   //////////////////////////Rendering de los equipos ///////////////////////////////
    $('#TeamInfo').html('');
   //[WHY] poruqe no un $.each, porque no se puede detener
   var unitTeamCounter=0;
   for (key in teams){
       team = teams[key];
      var teamDOM = renderTeam(team,true,region_id);
      $(teamDOM).appendTo('#TeamInfo');
      unitTeamCounter++;
   }
   
   //////////////////////////Rendering de boton de nuevos equipos ///////////////////////////////
   if(colony != false){
       var buttonDom = '<span class="button newteam">Crear equipo</span>';
       $('#TeamInfo').append(buttonDom);
   }
   
   
   //console.log(unitTeamCounter,'planet.js unitTeamCounter');
   //console.log(unitRegionCounter,'planet.js unitRegionCounter');
   //console.log(colony,'planet.js colony');
   if( (unitTeamCounter==0) && (unitRegionCounter == 0) && (colony==false) ){
       $('#TeamInfo').append('<p>La region no tiene tropas amigas</p>');

   }
   ///////BEHAVIOUR : Nuevo Equipo //////////////////   
   $( ".newteam" ).click(function(){
       callNewTeam();
   });
   
   ///////BEHAVIOUR : Sortable //////////////////
    $( ".team" ).sortable({
            connectWith: ".team,.teamWrapper",
            placeholder: "ui-state-highlight armyPlaceholder",
            forcePlaceholderSize:true,
             receive: function(event, ui) {
                 var dom =ui.item[0];
                 var army_id = getId(dom);
                 var parent = $(dom).parent('ul');
                 var team_id = getId(parent) ;
                 //console.log(ui,'ui');
                 //console.log(team_id,'team_id');
                 callTransferUnit(army_id,team_id);

             }
    }).disableSelection();
   ///////BEHAVIOUR : Close Button //////////////////
   $('.deleteTeam').click(function(){
       var id = $(this).parent('h4').data('team_id');
       callDeleteTeam(id);
   });
   
   ///////BEHAVIOUR : Active //////////////////
 $('.teamWrapper').click(function(){
     var team_id = $(this).data('team_id');
     activeTeam(team_id,this);
 })
 
 //BEHAVIOUR : Click the first Team
 if(exist( $('.teamWrapper')[0] )){
     $('.teamWrapper')[0].click();
 }
 
   
}

function renderTeam(team,deleteButton,regionId){
 //console.log(deleteButton,'render deleteButton');
 if(!exist(deleteButton)){
     deleteButton = true;
 }
 
 var deleteButtonDom = '';
 if(deleteButton== true){
     deleteButtonDom = '<span class="deleteTeam button">x</span>';
 }
 //console.log(deleteButton,'render deleteButton');
 //console.log(deleteButtonDom,'render deleteButton');
 
  var teamWrapper = $('<div class="teamWrapper ui-state-transparent"></div>');
   $(teamWrapper).data('team_id',team['id']);
   var h4 = $('<h4 class="ui-helper-clearfix ui-state-default">'+team['name']+deleteButtonDom+'</h4>').appendTo(teamWrapper);
   $(h4).data('team_id',team['id']);
   var ul = $('<ul id="t'+team['id']+'" class="team ui-helper-clearfix"></ul>').appendTo(teamWrapper);

   //console.log(ul,'planet fillTeamInfo');
   var armies = xeno['armies'][regionId];
   for(aKey in armies){
       var army = armies[aKey];
       if(army['team_id'] == team['id']){  
           var dom = '<li id="a'+army['id']+'" class="armyWrapper  '+army['allegiance']+'"><div class="army" ><img src="img/unit/'+army['creature_id']+'_small.png" class="army_turn myself small"><p>'+army['size']+'</p></div></li>';
           $(ul).append(dom);
       }
   }
   return teamWrapper;
}

function activeTeam(team_id,dom){
   //console.log('planet.js activeTeam team_id:'+team_id);
   $('.teamWrapper.ui-state-highlight').removeClass('ui-state-highlight').addClass('ui-state-transparent').find('h4').removeClass('ui-state-active').addClass('ui-state-default');
   $(dom).removeClass('ui-state-transparent').addClass('ui-state-highlight').find('h4').addClass('ui-state-active');
}

function getActiveTeamId(){
    var activeWrapper = $('#TeamInfoWrapper').find('.teamWrapper.ui-state-highlight');
    return $(activeWrapper).data('team_id');
}

function callDeleteTeam(team_id){
    waitMsg();
    $.ajax({
      type:'post',
      data:{'ajax_action':'delete_team','team_id':team_id,'planet_id':xeno['planet']['id']},
      url:g_planet_url,
      dataType:'json',
      error:function(XMLHttpRequest, textStatus, errorThrown){processAjaxError(XMLHttpRequest, textStatus, errorThrown);},
      success:function(data){processAjaxSuccess(data);fillTeamInfo(getActiveRegionId());}
    });
    return false;//Evitar la propagacion
}

function callNewTeam(){
    waitMsg();
    $.ajax({
      type:'post',
      data:{'ajax_action':'new_team','planet_id':xeno['planet']['id'],'region_id':getActiveRegionId()},
      url:g_planet_url,
      dataType:'json',
      error:function(XMLHttpRequest, textStatus, errorThrown){processAjaxError(XMLHttpRequest, textStatus, errorThrown);},
      success:function(data){processAjaxSuccess(data);fillTeamInfo(getActiveRegionId());}
    });
    return false;//Evitar la propagacion
}

function callTransferUnit(army_id,team_id){
    waitMsg();
    $.ajax({
      type:'post',
      data:{'ajax_action':'army_transfer_team','army_id':army_id,'team_id':team_id,'planet_id':xeno['planet']['id']},
      url:g_planet_url,
      dataType:'json',
      error:function(XMLHttpRequest, textStatus, errorThrown){processAjaxError(XMLHttpRequest, textStatus, errorThrown);},
      success:function(data){processAjaxSuccess(data);fillTeamInfo(getActiveRegionId());}
    });
    return false;//Evitar la propagacion
}

function showRegionInfo(){
  $("#InnerBattleReport").accordion( "activate",0);//TODO No hay variables magicas
}

function renderRegionActions(regionDOM){
    //console.log(regionDOM,'renderRegionsActions regionDOM');
  region_id = getRegionId(regionDOM);
  //console.log(region_id,'renderRegionsActions region_id');
  player_id = xeno['player']['id'];
  if(regionHasPlayer(region_id,player_id)){
    //console.log('renderREgionActions la region['+region_id+'] tiene jugaores');
    var x = parseInt(getRegionX(getRegionId(regionDOM)));
    var y = parseInt(getRegionY(getRegionId(regionDOM)));
    var max_x = parseInt(xeno['planet']['size']['x']);
    var max_y = parseInt(xeno['planet']['size']['y']);
    var list = Array();
    var position = Array();
    var c=0;
    //Obtenemos todas los tiles X adyacentes [maxima forma como cruz]
    
    //console.log('renderRegionAction x['+x+'] max_x['+max_x+']');
    if(x==0){
      list[c] = getRegionInXY(x+parseInt(1),y);
      position[c] = 'right';
      c++; 
    }
    else if(x==(max_x-1)){
      list[c] = getRegionInXY(x-1,y);
      position[c] = 'left';
      c++;
    }
    else{
      list[c] = getRegionInXY(x+parseInt(1),y);
      position[c] = 'right';
      c++;
      list[c] = getRegionInXY(x-1,y);
      position[c] = 'left';
      c++;
    }
    
    //console.log(list,'renderRegionAtions list');
    //console.log(position,'renderRegionAtions position');
    
    //Obtenemos todas los tiles y adyacentes [maxima forma como cruz]
    if(y==0){
      list[c]= getRegionInXY(x,y+parseInt(1));
      position[c] = 'bottom';
      c++;
    }
    else if(y==(max_y-1)){
      list[c]= getRegionInXY(x,y-1);
      position[c] = 'top';
      c++;
    }
    else{
      list[c]= getRegionInXY(x,y+parseInt(1));
      position[c] = 'bottom';
      c++;
      list[c]= getRegionInXY(x,y-1);
      position[c] = 'top';
      c++;
    }
    
    //console.log(list,'renderRegionAtions list');
    //console.log(position,'renderRegionAtions position');
    
    $.each(list,function(este){
      var DOM = "<div class='region_action_wrapper'>";
      DOM = DOM + "<div class='"+g_region_action_class+" "+position[este]+"'></div>";
      DOM = DOM +"</div>";
      $(list[este]).prepend(DOM);
    });
  }
  else{
      //console.log('renderREgionActions la region no tiene jugaores');
  }
}
function unrenderRegionActions(){
  $('.'+g_region_action_wrapper_class).remove();
}

function attackRegionAction(dom_action){
    waitMsg();
    var target_region_id = getRegionId($(dom_action).parents('.region'));
    var origin_region_id = getActiveRegionId();
    var teams = xeno['teams'][origin_region_id];
    var players =  xeno['players'];
    var myself = xeno['player'];
    var region = xeno['regions'][target_region_id];
    
    var activeTeamId = getActiveTeamId();
    if(!exist(activeTeamId)){
        warningMsg('Para enviar a atacar necesita enviar a las unidades dentro de un equipo');
    }
    else{
        $("#AttackRegionModal").dialog(
        {
            width: 240,
            modal: true,
            buttons: {
                "Atacar": function() {
                    //var team = teams[activeTeamId];
                    callAttackRegionAction(target_region_id,origin_region_id,activeTeamId);
                    $( this ).dialog( "close" );
                },
                Cancel: function() {
                    $( this ).dialog( "close" );
                }
            },
            title:'Atacar Region '+region['name'],
            open: function(event, ui) {

                //renderizar el equipo atacante

                var team = teams[activeTeamId];
                var teamDOM = renderTeam(team,false,origin_region_id);
                $('#AttackActiveTeam').html('');
                $(teamDOM).appendTo('#AttackActiveTeam');
                continueMsg();
                //renderizar unidades enemigas
                var armies = xeno['armies'][target_region_id];
                $('#AttackRegionEnemies').html('');
                if(exist(armies)){
                    //Obtener todos los players que no sean enemigos;
                    var enemyPlayersInRegion = new Array;
                    for(key in armies){
                        if(armies[key]["allegiance"]!='myself'){
                            enemyPlayersInRegion[armies[key]['player_id']] = armies[key]['player_id'];
                        }
                    }
                    if(enemyPlayersInRegion.length>0){
                        for( enemyKey in enemyPlayersInRegion){
                            var player = players[enemyKey];
                            var enemiesDom = renderArmies(enemyKey,target_region_id);
                            var title = '<h3 class="'+playerType(player,myself)+'">'+player['username']+'</h3>';
                            $('#AttackRegionEnemies').append(title+enemiesDom);
                        }
                        
                    }
                    else{
                        $('#AttackRegionEnemies').html('<p>No hay unidades enemigas</p>');
                    }
                    
                }
                else{
                    $('#AttackRegionEnemies').html('<p>No hay unidades enemigas</p>');
                }
                
                


            }
        });
    }
}
 function callStatus(){
    //deactiveRegions();
   waitMsg();
    $.ajax({
      type:'post',
      data:{'ajax_action':'status','planet_id':xeno['planet']['id']},
      url:g_planet_url,
      dataType:'json',
      error:function(XMLHttpRequest, textStatus, errorThrown){processAjaxError(XMLHttpRequest, textStatus, errorThrown);},
      success:function(data){
        processAjaxSuccess(data);  
        //activeRegion(origin_region_id);
        }
        
    });
}

 function callAttackRegionAction(target_region_id,origin_region_id,team_id){
    //deactiveRegions();
   waitMsg();
    $.ajax({
      type:'post',
      data:{'ajax_action':'attack_region','planet_id':xeno['planet']['id'],'target_region_id':target_region_id,'origin_region_id':origin_region_id,'team_id':team_id},
      url:g_planet_url,
      dataType:'json',
      error:function(XMLHttpRequest, textStatus, errorThrown){processAjaxError(XMLHttpRequest, textStatus, errorThrown);},
      success:function(data){
        processAjaxSuccess(data);  
        activeRegion(origin_region_id);
          
        }
        
    });
}

/***********************************************************
 * RESOURCES
 **********************************************************/
function fillResourcesMenu(){
  var DOM = '<ul>';
  var iDOM ='';
  var count =0;
  var resources = xeno['planet']['resources'];
  
  if(resources!=null){
  $.each(resources,function(key,resource){
     iDOM = iDOM +'<li>'+renderResource(resource)+'<span class="username">'+resource['username']+'</span></li>';
     count++; 
   });
   if(count==0){
      iDOM = '<p>Esta Region no Tieneeee recursos</p>';
      DOM = iDOM;
   }
   else{
    DOM = DOM + iDOM + '</ul>';
   }
    $("#ResourcesMenu").html(DOM);
   }
}

function renderColony(colony){
  var alle = colony["allegiance"];
  var DOM = '<img class="colony '+alle+'" src="'+g_image_url+'building/colony'+colony['type']+'_small.png ">';  
  return DOM;
}

function renderResource(resource){
  var DOM = '<img class="resource" src="'+g_image_url+'resource/'+resource['resource_id']+'_'+resource['quality']+'.png ">';  
  return DOM;
}
function renderResourceProportion(resource){
  prop = 0;
  switch(resource['quality']){
    case 'P':
    prop =1;
    break;
    case 'R':
    prop =2;
    break;
    case 'H':
    prop =3;
    break;
    case 'S':
    prop =5;
    break; 
  }
  DOM ='';
  for(var x=0;x<prop;x++){
   DOM = DOM + '<img class="resource" src="'+g_image_url+'resource/'+resource['resource_id']+'_1.png ">'; 
  }
    
  return DOM;
  
}

/***********************************************************
 * HABILIDADES
 **********************************************************/
function fillAbilitiesMenu(){
  var abilities = xeno['player']['abilities'];
  var DOM ='<ul id="Abilities">';
  //El jugador no tiene habilidades
  if(abilities.length==0){
    DOM = DOM + '<li>El jugador no tiene habilidades</li>';
  }
  else{
    $.each(abilities,function(key,value){
      DOM =DOM + '<li id="ability'+key+'" class="ability"><img src='+g_image_url+'ability/'+key+'.png /><span class="title">'+value['name']+'</span><span class="energy"> '+value['energy']+'</span> <span class="desc"> '+value['desc']+'</span></li>';
    });
    DOM = DOM + '</ul>';
  }
  $('#AbilitiesMenu').html(DOM); 
} 

/***********************************************************
 * ACTIVADORES
 **********************************************************/
  function activeAbility(dom){
    if($(dom).hasClass('active')){
      deactiveAbilities();  
    }
    else{
      deactiveAbilities();
      $(dom).toggleClass("active");
    }
  }
  function deactiveAbilities(){
    $('li.ability.active').removeClass('active');//Quita lo seleccionado de una accion
  }
  
  
   function activeRegion(id){
   dom = getRegion(id);
   if($(dom).hasClass('active')){
      deactiveRegions();  
    }
    else{
      deactiveRegions();
      $(dom).toggleClass("active");
      renderRegionActions(dom);
    }
  }
  
  function deactiveRegions(){
    unrenderRegionActions();
    $('.region.active').removeClass('active');//Quita lo seleccionado de una accion
  }
  
/***********************************************************
 * OBTENEDORES DE ID
 **********************************************************/
function getAbilityId(dom){
  var id_raw = $(dom).attr('id');
  if (typeof(id_raw)!='undefined')
  {
    return parseInt(id_raw.substring(7));}
  else{
    return false;
  }
}
function getActiveAbilityId(){
   var ability_id = getAbilityId($('ul#Abilities li.ability.active').eq(0));
   return ability_id;
 }

 function getRegionId(dom){
  var id_raw = $(dom).attr('id');
  if (typeof(id_raw)!='undefined')
  {
    return parseInt(id_raw.substring(6));}
  else{
    return false;
  }
 }
 /*function isPathable(target_tile){
   return false;
 }*/
 /***********************************************************
 * OBTENEDORES DE DOM
 **********************************************************/
 function getRegionInXY(x,y){
    // console.log('x['+x+']  y['+y+']');
  total_y = xeno['planet']['size']['y'];  
  x= parseInt(x);
  y= parseInt(y);
  total_y= parseInt(total_y);
  index=(y*total_y)+x+parseInt(1);
  //console.log(' (y* total_Y) + x + 1');
  //console.log('x['+x+'] total_y['+total_y+'] y['+y+'] index['+index+']');
  tile = $('.index'+index); 
  return tile;
}
function getActiveRegionId(){
  var active_region = $('.region.active')[0];
  var id = getRegionId(active_region);
  return id;
}

 
 function getRegion(id){
   var reg = $('#Region'+id);
   return reg;
 }
 function getRegionX(id){
   var reg = getRegion(id);
   return $(reg).attr('x');
 }
 function getRegionY(id){
   var reg = getRegion(id);
   return $(reg).attr('y');
 }
function getRegionIndex(id){
   var reg = getRegion(id);
   return $(reg).attr('index');
 }
 
 function getPlayersByRegionId(region_id){
     var armies = xeno['armies'][region_id];
     var players = new Object;
     /*console.log(players,'planet.js getPlayersByRegionId players Empty?');
    console.log(armies,'planet.js getPlayersByRegionId armies');
    console.log(typeof(armies),'planet.js getPlayersByRegionId typeofarmies');
    console.log(armies.length,'planet.js getPlayersByRegionId armies.lenght');*/
    
    for(key in armies){
        //console.log(players,'getPLayersByRegionId player iteration pre');
        var army = armies[key];
        var player_id = army['player_id'];
        players[player_id] = xeno['players'][player_id];
        //console.log(players,'getPLayersByRegionId player iteration post');
    }
    return players;
}

 
 function getPlayerByIdAndRegionId(player_id,region_id){
  var regionvalue = 'to_region';//Id para buscar la region
  //console.log(player_id,'planet.js->getPlayerByIdAndRegionId->player_id');
  //console.log(region_id,'planet.js->getPlayerByIdAndRegionId->region_id');
   players = xeno['players'];
   //[WHY] poruqe no un $.each, porque no se puede detener
   for (key in players){
     var player = players[key];
    // console.log(player,'planet.js->getPlayerByIdAndRegionId->player tiene id?');
     if(player['id']==player_id){
       if(player[regionvalue]==region_id){
       // console.info('Player['+player['id']+' ]reg['+player['region_id']+'] encontrado','getPlayerByIdAndRegionId');
         return player;
       }
       else{
         //console.info('Player['+player['id']+' ]reg['+player[regionvalue]+'] != region['+region_id+']','getPlayerByIdAndRegionId');
       }
     }
     //console.info('Player['+player['id']+' ] != player['+player_id+'] buscado','getPlayerByIdAndRegionId');
   }
   return false;
 }
 
 
 
 /***********************************************************
 * BOLEANOS
 **********************************************************/ 
 function armiesHasPosition(position,player_id,region_id){
   var myArmies = xeno['armies'][region_id];
   var hasPosition = false;
    $.each(myArmies,function(key,army){
      if((army['player_id']==player_id)&&(army['region_id']==region_id)){
          if(army['position']==position){
            hasPosition = true;           
          }
      }
        
    })
    return hasPosition;
   
 }
 function regionHasPlayer(region_id,player_id){
   players = getPlayersByRegionId(region_id);
   //console.log(players,'region['+region_id+']HasPlayer['+player_id+'] players');
   hasPlayer = false;
   
   for(key in players){       
       var player = players[key];
       if(player['id'] == player_id){
          //console.info(players[player_id]['region_id']+ '==' +region_id,'regionHasPlayer planet.js');
          hasPlayer = true;
          return hasPlayer;  
       }
       else{
           //console.log('regionHasPLayer2 player['+player['id']+']!= player_id['+player_id+']');
       }
   }
   return hasPlayer;
 }


function renderPlanetMap(){
    
    var regions = xeno['regions'];
    var planet = xeno['planet'];
      if(isDefined(regions))
    {
        var dom='<table class="planet_map" id="PlanetMap'+planet['id']+'" style="background-image:url('+g_image_url+'region/region'+planet['color']+'.jpg)">';
            
            var sides = planet['size'];
            //debug::log($sides,'planetstate->render1');
            //Calcular la anchura
            var calc = 600/sides['y'];
            var width = Math.ceil(calc);//_X_ITF_PLANET_WIDTH
            var widthClass='side'+width;
            for(var y=0;y<sides['y'];y++)
            {
                dom=dom+"<tr id='y"+y+"' class='"+widthClass+"'>";
                for(var x=0;x<sides['x'];x++)
                {
                    //debug::log('planetstate->render3');
                    var data='';
                    var col = '<div class="colonies"></div>';
                    var res = '<div class="resources"></div>';
                    var index=(y*sides['y'])+(x+1);
                    var regionMAU = findRegionByPosition(regions,index);
                    if(isDefined(regionMAU) ){
                        var region_id = regionMAU['id'];   
                        dom=dom+"<td x="+x+" y="+y+" index="+index+" id='Region"+region_id+"' class='x"+x+" y"+y+" region index"+index+" "+widthClass+"' >"+data+col+res+'</td>';
                    }
                    else{
                    dom=dom+"<td class='noregion "+widthClass+"' >"+data+col+res+'</td>';
                    }
                }
                dom=dom+"</tr>";
            }
            dom=dom+'</table>';
            }
    else{
        dom='<table class="battle_map"><tr><td>Planeta No Accesible</td></tr></table>';
    }
    $('#Content').html(dom);
}

function findRegionByPosition(regions,position){
    var region = _.find(regions, function(region){ 
        if(region['planet_position']== position){return true}else{return false}
    });
    return region;
}