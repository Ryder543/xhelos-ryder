<?php
 require_once(dirname ( __FILE__ ).'/security.php'); //Advertencia de Seguridad
 /********************************************************
 * player: Clase para el manejo del jugador, esta en forma lazy 
 ******************************************************/

class planetman  extends identitymap
{
  protected  function __construct(){
    parent::__construct('planetman','planet','planets');
  }
    
	//////////////////////////////////////////////////////////////////////////////////	
	//Variables
	///////////////////////////////////////////////////////////////////////////////////
        private static $instance;//Contiene la instancia unica
	
    //////////////////////////////////////////////////////////////////////////////////
    //Metodos
    //////////////////////////////////////////////////////////////////////////////////
      public function createDt($data){
          $sql="INSERT INTO planets(id, \"name\", state, \"desc\", star_id, orbit, size, color, variation,\"order\")".
          "VALUES (".$data["id"].",'".$data["name"]."','".$data["state"]."','".$data["desc"]."',".$data["star_id"].",".$data["orbit"].
          ",'".$data["size"]."', '".$data["color"]."', '".$data["variation"]."', ".$data["order"].")";
          $dt = $this->db->insertDt($sql);
          if($dt->isValid){
              $dt->setData($data);
          }
          return $dt;
      }

      //////////////////////////////////////////////////////////////////////////////////  
    //UTILITARIOS
    ///////////////////////////////////////////////////////////////////////////////////   	
    /********************************************************************
    * Singleton, devuelve la instancia del singleton
    *********************************************************************/
    public static function singleton(){//Obtiene la instancia unica de esta clase
            if(!isset(self::$instance)) {
                    $c = __CLASS__;
                    self::$instance = new $c;
            }
            return self::$instance;
    }
    /********************************************************************
    * Clone: Prohibe que algun sapazo clone un singleton
    *********************************************************************/
   public function __clone() // Prevenimos que este objeto sea clonado
   {
       trigger_error('Clone is not allowed. db_pg_class', E_USER_ERROR);
   }

    public function defaultsql($id) {
        $sql = "SELECT * FROM planets WHERE id = ".$id;
        return $sql;
    }
}

?>