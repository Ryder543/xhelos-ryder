<?php

  require_once(dirname ( __FILE__ ).'/../security.php'); //Advertencia de Seguridad

  /*Clase Abstracta que indica que tiene un datatransfer que puede ser manejado
  * Util si se quiere concatenar varias llamadas de un dt y preguntar si todo salio
  *  a pedir de boca   */
  
  abstract class dtstate{
    //protected $refresh;   
    protected $dt;    
    //////////////////////////////////////////////////////////////////////////////////
    //CONSTRUCTOR
    //////////////////////////////////////////////////////////////////////////////////
    public function __construct(){
          /* $dt = new datatransfer();
           $dt->success("Success Inicial");*/
           /*$this->setOkDt($dt);*/
    }
    
    public function getDt(){
        if(empty ($this->dt)){
            $this->dt = new datatransfer();
            $this->dt->success("DATATRANSFER INICIAL");
        }
        return $this->dt;
    }
    
    //Setea esta variable SOLO si DT antiguo es ok (valido) si no no setea nada. Util para guardar la ultima ves que exploto algo
    public function setOkDt($dt){
        if($this->getDt()->ok()){
            $this->dt = $dt;
        }
    }
    
    //Setea esta variablea BAD
    public function setBadDt($text,$data=false){
        $dt = new datatransfer();
        $dt->error($text,$data);
        $this->dt = $dt;
    }
     //Setea esta variablea BAD
    public function setWarningDt($text,$data=false){
        $dt = new datatransfer();
        $dt->invalidWarning($text,$data);
        $this->dt = $dt;
    }
    
    public function isOk(){
        return $this->getDt()->ok();
    }
    
   /*

    public function setRefresh($refresh){
        $this->refresh = $refresh;
    }
    public function getRefresh(){
        return $this->refresh;
    }    
    public function refreshIt(){
        $this->refresh = true; //Refresca el cliente
    }*/
    
    
  }

?>