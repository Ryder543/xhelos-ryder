<?php

  require_once(dirname ( __FILE__ ).'/../security.php'); //Advertencia de Seguridad

  abstract class jax extends dtstate{
      
      protected $id;
      protected $gs;
      protected $type;      
      protected $requestParams;


      public function __construct(){

           $this->prepareRequestParams();
           //$this->init();
           parent::__construct();
     }
     
     public function init($id,$type){
         $this->setId($id);
         $this->setType($type);
         $this->gs = new globalview($this->getId(),$this->getType());
         $db = db::singleton();
         $db->begin();

     }

     public function send() {
            $db = db::singleton();        
            
            if($this->isOk()){
                $db->commit();
                $this->getGs()->renderAjaxData();
            }
            else{
                $db->rollback();
                ajaxutil::sendAjaxError($this->getDt());
            }
    }
    
    //////////////////////////////////////////////////////////////////////////////////
    //GETTERS and SETTERS
    //////////////////////////////////////////////////////////////////////////////////   
     public function setId($id){
         $this->id=$id;
     }
     public function getId(){
         return $this->id;
     }
     public function getGs(){
         return $this->gs;
     }
     public function setType($type){
         $this->type = $type;
     }
     public function getType(){
         return $this->type;
     }
     
     public function getRequestParam($varName){
         if(isset($this->requestParams[$varName])){
            return $this->requestParams[$varName];
         }
         else{
             return false;
         }
     }
     public function getParam($varName){
         return $this->getRequestParam($varName);
         
     }     
     
     //Private porque deberian de usar los valNumericRequestParam
     private function setRequestParam($varName,$value){
         $this->requestParams[$varName] = $value; 
     }
     
     protected function valNumericRequestParam($varName){
        if($this->isOk()){
            if(isset($_POST[$varName])){
                $numeric = validator::filter_integer($_POST[$varName]);
                if(!$numeric){
                    if($numeric==0){
                        $this->setRequestParam($varName,$numeric);
                    }
                    else{
                        debug::error("jax.class->valNumericRequestParam variable REQUEST[".$varName."][".$_POST[$varName]."] no es un integer");
                        $this->setBadDt("Variable [".$varName."] no existe");
                    }
                }
                else{
                    $this->setRequestParam($varName,$numeric);
                }
            }
            else{
                debug::error("jax.class->valNumericRequestParam variable REQUEST[".$varName."] no esta definida");
                $this->setBadDt("Variable [".$varName."] no existe");
            }  
        }
     } 
     
       protected function valNumericAndNullRequestParam($varName){
        if($this->isOk()){
            if(isset($_POST[$varName])){
                $numeric = validator::filter_integer_and_null($_POST[$varName]);
                if(!$numeric){
                    if($numeric==0){
                        $this->setRequestParam($varName,$numeric);
                    }
                    else{
                        debug::error("jax.class->valNumericRequestParam variable REQUEST[".$varName."][".$_POST[$varName]."] no es un integer");
                        $this->setBadDt("Variable [".$varName."] no existe");
                    }
                }
                else{
                    $this->setRequestParam($varName,$numeric);
                }
            }
            else{
                debug::error("jax.class->valNumericRequestParam variable REQUEST[".$varName."] no esta definida");
                $this->setBadDt("Variable [".$varName."] no existe");
            }  
        }
     }  
     
    protected function valStringRequestParam($varName){
        if($this->isOk()){
            if(isset($_POST[$varName])){
                $string = validator::filter_string($_POST[$varName]);
                if(!$string){
                    debug::error("jax.class->valStringRequestParam variable REQUEST[".$varName."][".$_POST[$varName]."] no es un string o no se pudo validar");
                    $this->setBadDt("Variable [".$varName."] no se valido o filtro como string");
                }
                else{
                    $this->setRequestParam($varName,$string);
                }
            }
            else{
                debug::error("jax.class->valStringRequestParam variable REQUEST[".$varName."] no esta definida");
                $this->setBadDt("Variable [".$varName."] no existe");
            }  
        }
     } 
     
     
     //////////////////////////////////////////////////////////////////////////////////
    //METODOS UTILITARIOS
    //////////////////////////////////////////////////////////////////////////////////   
    public function getCurrentPlayer(){
       if($this->isOk()){
            return $this->gs->getPlayer();
       }
    }
    
    public function getOState(){
        return $this->getGs()->getOState();
    }
    
    
     ////////////////////////////////////////////////////////////////////////////////////////////////////
    //doWork, esta clase ejeucta la accion y cambia el estado de jax segun lo que devuelva el work
    /////////////////////////////////////////////////////////////////////////////////////////////////////
     protected function doWork(work $work){
         $work->valAndExec();
         if($work->isOk()){
             $this->setOkDt($work->getDt());
         }
         else{
             $this->setBadDt($work->getDt()->getText());
         }
         
     }
    //////////////////////////////////////////////////////////////////////////////////
    //METODOS ABSTRACTOS
    //////////////////////////////////////////////////////////////////////////////////
     abstract protected function prepareRequestParams();
     
  }
  

?>