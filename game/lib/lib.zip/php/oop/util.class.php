<?php

  require_once(dirname ( __FILE__ ).'/../security.php'); //Advertencia de Seguridad

  abstract class util extends dtstate{
    protected $db;

    //////////////////////////////////////////////////////////////////////////////////
    //CONSTRUCTOR
    //////////////////////////////////////////////////////////////////////////////////
    public function __construct(){
        $this->db = db::singleton();
    }

    //Retorna el Manager Asociado a esta variable!
    public function man($name){
        $managerClass = $name . 'man';
        //debug::log($managerClass,'identity->man1');
        $obj = eval('return '.$managerClass.'::singleton();'); //[TODO] no deberiamos pero...
        return $obj;
    }
    
    public function getCurrentPlayer() {
        return session::getCurrentPlayer();//[TODO] Eliminar esta funcion porque session puede obtenerlo todo
    }

  }

?>