<?php

require_once(dirname(__FILE__) . '/../security.php'); //Advertencia de Seguridad

/**
 * Clase que nos permite controlar un datatransfer por objeto. Con este objeto
 * podemos saber facilmente cual es el estado success o error de la clase.
 * Muy util para clases que tienen que hacer un monton de validaciones y 
 * saber el estado interno del objeto sin necesidad de pasar un datatransfer
 * como parametro
 * is the main contact email.
 *
 * Nada especial con el constructor.
 *
 * @category  Xhelos
 * @package   Main
 * @license   http://www.opensource.org/licenses/BSD-3-Clause
 * @example   lib/php/act/regionColonyCreateColonyAction.php
 * @version   0.01
 * @since     2012-dic-23
 * @author    Jeeba <designbyjeeba@gmail.com>
 */
abstract class work extends dtstate {

    /**
     * Objeto Datatransfer que mantiene el estado success/error de la pagina.
     * @var datatransfer
     */
    protected $dt;
    protected $jax;

    public function __construct(jax $jax) {
        $this->jax = $jax;
    }

    //////////////////////////////////////////////////////////////////////////////////
    //METODOS PRINCIPALES
    //////////////////////////////////////////////////////////////////////////////////  

    /**
     * Valida primero y despues ejecuta la accion. Una vez finalizada la accion
     * este objeto contiene en su dt el estado actual de la accion. Por lo que 
     * podemos saber si la accion ha sido realizada consultando al dt. Este se 
     * parara en el primer error encontrado si lo hubiere
     *
     * @return  None
     * @since   2012-Dic-23
     * @author  Jeeba <designbyjeeba@gmail.com>
     *
     * @edit    2012-Dic-23<br />
     *          Jeeba <designbyjeeba@gmail.com>
     *          Funcionalidad Inicial<br/>
     *          #edit1
     */
    public function valAndExec() {
        $this->validate();
        if ($this->getDt()->ok()) {
            $this->execute();
        }
    }

    //////////////////////////////////////////////////////////////////////////////////
    //GETTER AND SETTER
    //////////////////////////////////////////////////////////////////////////////////   
    protected function getParam($varName){
        return $this->getJax()->getParam($varName);
    }
    protected function getCurrentPlayer(){
        return $this->getJax()->getCurrentPlayer();
    }  
    protected function getJax(){
        return $this->jax;
    }
    //////////////////////////////////////////////////////////////////////////////////
    //METODOS ABSTRACTOS
    //////////////////////////////////////////////////////////////////////////////////
    //Parametro mandamos el objeto que nos dara los parametros que necesitamos
    abstract public function validate(); //Envia los datos como ajax

    abstract public function execute(); //Envia los datos como ajax    
    
    abstract protected function validateParams();
}

?>