<?php
 require_once(dirname ( __FILE__ ).'/security.php'); //Advertencia de Seguridad
/****************************************************************
 * debug: Clase para medir performance y mandar mensajes de error 
 ***************************************************************/
class ajaxutil
{
    static function getAffectsConstants(){
            //Crear la estructura affect
      $affect[_X_AFFECTS_ATTACK]="attack";
      $affect[_X_AFFECTS_ATTRITION]="attack";
      $affect[_X_AFFECTS_ARMOR]="armor";
      $affect[_X_AFFECTS_LIFE]="life";
      $affect[_X_AFFECTS_UNIT]="unit";
      $affect[_X_AFFECTS_MOVEMENT]="movement"; 
      //$affect = json_encode($affect);
      return $affect; 
    }
    
    static function getPositionsConstants(){
      $position[_X_POSITION_ORBIT]="En Orbita";
      $position[_X_POSITION_ATERRIZAR]="Aterrizando en region";
      //$position[_X_POSITION_SALIENDO]="Saliendo a la Orbita";
      $position[_X_POSITION_SUPERFICIE]="En Superficie";
      $position[_X_POSITION_ESPACIO]="En el Espacio";
      //$position[_X_POSITION_OUTSIDE]="Moviendose a Region";
      //$position[_X_POSITION_INSIDE]="Entrando a Region";
      $position[_X_POSITION_COORD_NULL]="Nulo";
      //$position = json_encode($position);
    
      return $position;
    }
    
    static function getBattlePhases(){
      $phases[_X_BATTLE_PHASE_TACTIC]="Tactica";
      $phases[_X_BATTLE_PHASE_BATTLE]="Batalla";
      $phases[_X_BATTLE_PHASE_END]="Finalizada";
      return $phases;
    }
    
    static function json_encode($a){
        return json_encode($a);
        //json_encode($arr, JSON_FORCE_OBJECT);
    }

/* * ********************************************* */
/* 	Caso: Mandar de PHP a Javascript	   */
/* * ********************************************* */
    static function php2js($var, $varname, $echo_on = true) {
        $script = "<script type='text/javascript'>";
        $script = $script . "$varname = eval($var)";
        $script = $script . "</script>";
        if ($echo_on) {
            echo $script;
        } else {
            return $script;
        }
    }
    
    static function var2json($var,$returnIsEchoed=true)
    {
            if(isset($var))
            {
                    if($returnIsEchoed)
                    {
                            //echo "[".json_encode($var)."]";
                            //echo "(".json_encode($var).")";
                            //debug::log(json_encode($var),'var2json json_encode');
                            //debug::log($var,'var2json var');
                            echo json_encode($var);
                    }
                    else{
                            return json_encode($var);
                            //return json_encode($var);
                    }
                    //echo '{"hola:"'.json_encode($var).'"}';
                    //echo json_encode($var);
            }
            else
            {
                    //echo 'ERROR: La variable no esta seteada. FUNCION: json.var2json';
            }
    }
 
    
    static function calculateState(view $oState,view $oGlobal){
        $state_raw = $oState->getState();
        $global = $oGlobal->getState();
        $state_raw['global'] = $global;
        return $state_raw;
    }
    static function calculateMsgState(datatransfer $dt,view $oState,view $oGlobal){
        $state = ajaxutil::calculateState($oState,$oGlobal);
        $state['msg'] = $dt->getMsg();
        return $state;
    }
    
    static function sendAjax(datatransfer $dt,view $oState,view $oGlobal){
        // Prevent caching.
        header('Cache-Control: no-cache, must-revalidate');
        header('Expires: Mon, 01 Jan 1996 00:00:00 GMT');
        // The JSON standard MIME header.
        header('Content-type: application/json ; charset=UTF-8');
        //header('Content-Type: text/javascript');
        //header('Content-Type: text/plain');

        $state = ajaxutil::calculateMsgState($dt,$oState,$oGlobal);
                
        //debug::log($state,'ajaxUtil sendAjax');
        echo ajaxutil::var2json( ajaxutil::json_encode($state,'xeno') );
    }
    static function sendHtml(datatransfer $dt,view $oState,view $oGlobal){
        $state_raw = ajaxutil::calculateMsgState($dt,$oState, $oGlobal);
        $state = ajaxutil::json_encode($state_raw);
        $affect = ajaxutil::json_encode(ajaxutil::getAffectsConstants() );
        $position = ajaxutil::json_encode( ajaxutil::getPositionsConstants() );
        $phases = ajaxutil::json_encode(ajaxutil::getBattlePhases());
        echo ajaxutil::php2js($state,'xeno');
        echo ajaxutil::php2js($affect,'affect');
        echo ajaxutil::php2js($position,'position');
        echo ajaxutil::php2js($phases,'phases');
        echo ajaxutil::php2js(_X_HIDDEN_TIME,'_X_HIDDEN_TIME');
        echo ajaxutil::php2js(_X_TOTAL_RESOURCES,'_total_resources');
    }
    static function sendError(datatransfer $dt){
        $state = ajaxutil::json_encode($sdt);
        echo ajaxutil::php2js($state,'xeno');
    }
    
    static function sendAjaxError(datatransfer $dt){
        header('Cache-Control: no-cache, must-revalidate');
        header('Expires: Mon, 01 Jan 1996 00:00:00 GMT');
        header('Content-type: application/json ; charset=UTF-8');
        echo ajaxutil::var2json( ajaxutil::json_encode($dt,'xeno') );
    }    
  }
?>
