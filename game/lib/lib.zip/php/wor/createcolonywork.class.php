<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of regionColonyCreateColony
 *
 * @author windows7
 */
class createcolonywork extends work {
    //put your code herepublic function execute(){

    
    public function execute() {
        debug::log("TEMPORAL 10 -  Ejecucion Creacion de Colonia","createcolowoekclass");
    }

    public function validate() {
        $this->setOkDt($this->validateMaxColonyDt());
        $this->setOkDt($this->validateResourcesAvailableDt());
        $this->setOkDt($this->validateFreePositionDt());
        $this->setOkDt($this->validateNotNearBordersDt());
        $this->setOkDt($this->validateNotNearOtherBuildingsDt());
        $this->setOkDt($this->validatePlanetaryPassDt());
        $this->setOkDt($this->validateRegionalPassDt());
        $this->setOkDt($this->validateStellarPassDt());
    }
    
    private function validateMaxColonyDt(){
        return $this->getDt()->success("TEMPORAL1","regionColonyCreateColonyAction");
    }
    private function validateResourcesAvailableDt(){
        return $this->getDt()->success("TEMPORAL2","regionColonyCreateColonyAction");
    }
    private function validateFreePositionDt(){
        return $this->getDt()->success("TEMPORAL3","regionColonyCreateColonyAction");
    }    
    private function validateNotNearBordersDt(){
        return $this->getDt()->success("TEMPORAL4","regionColonyCreateColonyAction");
    }    
    private function validateNotNearOtherBuildingsDt(){
        return $this->getDt()->success("TEMPORAL5","regionColonyCreateColonyAction");
    }
    private function validateRegionalPassDt(){
        return $this->getDt()->success("TEMPORAL6","regionColonyCreateColonyAction");
    }
    private function validatePlanetaryPassDt(){
        return $this->getDt()->success("TEMPORAL7","regionColonyCreateColonyAction");
    }
    private function validateStellarPassDt(){
        return $this->getDt()->success("TEMPORAL8","regionColonyCreateColonyAction");
    }

    protected function validateParams() {
        
    }
}

?>
