<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Clase Work que mueve unidades hacia varias direcciones
 *
 * @author windows7
 */
class enterunittoregionwork extends work {
    //put your code herepublic function execute(){

    
    public function execute() {
        debug::log("TEMPORAL 10 -  Ejecucion Creacion de Colonia","enterunittoregionwork");
        
        
        
    }

    public function validate() {
        //$this->setOkDt($this->validateMaxColonyDt());
    }
    
 
}

?>
